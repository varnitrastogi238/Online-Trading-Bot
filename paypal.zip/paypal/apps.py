from django.apps import AppConfig


class PaypalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'paypal'
