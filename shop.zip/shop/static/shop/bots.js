document.querySelector('.take_me_home').addEventListener('click',function(e){
    console.log('el');
    location.href= "./home.html";
})